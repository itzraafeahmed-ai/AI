// Theme Toggle
const toggleBtn = document.getElementById("themeToggle");

toggleBtn.addEventListener("click", () => {
  document.body.classList.toggle("dark");
});

// Charts

// Line Chart
new Chart(document.getElementById("lineChart"), {
  type: 'line',
  data: {
    labels: ["Jan", "Feb", "Mar", "Apr", "May", "Jun"],
    datasets: [{
      label: "Sales",
      data: [12000, 19000, 15000, 22000, 18000, 25000],
      borderColor: "#4e54c8",
      fill: true,
      backgroundColor: "rgba(78,84,200,0.2)"
    }]
  }
});

// Pie Chart
new Chart(document.getElementById("pieChart"), {
  type: 'pie',
  data: {
    labels: ["Electronics", "Clothing", "Food"],
    datasets: [{
      data: [40, 30, 30],
      backgroundColor: ["#4e54c8", "#28a745", "#ffc107"]
    }]
  }
});

// Orders Data
const orders = [
  { id: "#1001", name: "John", product: "Laptop", amount: "₹50000", status: "Completed", date: "2026-04-01" },
  { id: "#1002", name: "Sara", product: "Shoes", amount: "₹3000", status: "Pending", date: "2026-04-03" },
  { id: "#1003", name: "Mike", product: "Phone", amount: "₹20000", status: "Cancelled", date: "2026-04-04" },
];

// Render Table
const table = document.getElementById("orderTable");

function renderTable(data) {
  table.innerHTML = "";
  data.forEach(order => {
    table.innerHTML += `
      <tr>
        <td>${order.id}</td>
        <td>${order.name}</td>
        <td>${order.product}</td>
        <td>${order.amount}</td>
        <td><span class="badge bg-${getStatusColor(order.status)}">${order.status}</span></td>
        <td>${order.date}</td>
      </tr>
    `;
  });
}

function getStatusColor(status) {
  if (status === "Completed") return "success";
  if (status === "Pending") return "warning";
  return "danger";
}

renderTable(orders);

// Search Filter
document.getElementById("searchInput").addEventListener("keyup", (e) => {
  const value = e.target.value.toLowerCase();
  const filtered = orders.filter(o =>
    o.name.toLowerCase().includes(value) ||
    o.product.toLowerCase().includes(value)
  );
  renderTable(filtered);
});